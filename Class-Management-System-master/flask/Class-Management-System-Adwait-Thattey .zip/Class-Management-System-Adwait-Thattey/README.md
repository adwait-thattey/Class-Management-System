## PROJECT NAME : CLASS MANAGEMENT SYSTEM ##

<b><i>ITWS-2 Project 2k18 </i></b>  
  
<br>  
    
### GROUP MEMBERS : ### 
        
        1. Adwait Thattey (201701004)  
        2. Brijesh Bumrela (201701031)  
        3. Ankur Gupta (201701013)  
        4. Harshith Bathula (201711194)  
        5. Aaquib Niaz (201701002)  
        6. Bittu Kumar Ray (201701027)  
        

### Aim : Our project aims at creating a Class Management System. ###

### The current expected features are : ###
        1. Creating and Maintaining Records of Every Student and Faculty
        2. Maintaining of the capacity and state of each Classroom , Lab , other rooms
        3. Creating Time-Table for every batch and faculty. (Main Feature)
        4. Creting Schedule for Exams
        5. Allocating Classroom to individual students during Exam.`
        6. GUI based interface (Low Priority)
        
### Individual Tasks  : ###

        Adwait and Ankur : Working on genetic Algorithm for time-table and exam scheduling
        Aaquib and Brijesh : Developing UI(CLI and GUI using Flask) , Passwords handling and storage(Encryption)
        Bittu and Harshith : Handling the entire data module and testing of various other modules and entire project.

### Milestones : ###
        1. Researching , Learning and implementing genetic algoeithms for generating Time-Table
        3. Parallely implementing all features seperately.
        4. Combining all features and joining them together.
        5. Debugging the project
        6. Creating User-Interface (Command Line Interface)
        7. Creating User-Interface (GUI : Either Python or Web-Gui using Flask)
